
  /* API WHOIS Lookup 
  License: MIT Common License 
  G. Matyila - 2016
  */
		var Client = Client || {};
		Client.Services = {
			Responses: {
				Available: "<br/>This domain will be registered it's available - <img src='img/tick.png' width='128px'/> <i class='label label-primary'> Continue to form below </i>",
				Unavailable: "<br/><img src='img/x.png' width='128px' /> Not available for registration",
				OrderMessage: " - is Available please register on my behalf send me quotation"
			}
		}
		function DataInfo(){
			var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function(){
				  if(xhttp.readyState == 4 && xhttp.status == 200){
					  var DataResponse = JSON.parse(xhttp.responseText);
						function Validator(){
					 if(DataResponse.registered !== true){
						    document.getElementById('DataSet').innerHTML = Client.Services.Responses.Available;
						  document.getElementById('processOrder').value = document.getElementById('DomainChecker').value + Client.Services.Responses.OrderMessage; 
					  }else{
						 document.getElementById('DataSet').innerHTML = Client.Services.Responses.Unavailable;
					  }
						}
						Validator();
				  }else{
					  console.log('process executed');
				  }
			  }
			xhttp.open("get",'http://api.whoapi.com/?apikey=952c8451a7a5618274bea0185cbe1fbc&r=whois&domain=google.com', true );
		  xhttp.send();	
		}
     /* Api ends */